<?php
$name=$_GET["name"];
$email=$_GET["email"];
$city=$_GET["city"];
$uname=$_GET["uname"];
$pwd=$_GET["pwd"];
$con=mysqli_connect("localhost","root","","phptest");
$sql="Insert into users2 values ('$name','$email','$city','$uname','$pwd')";
if (mysqli_query($con,$sql))
{
echo "User Record Inserted";
}
else
{
	echo "Unable to Insert Record ... Try again";
}
?>