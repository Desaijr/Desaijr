<?php
$name=$_GET["x"];
$con=mysqli_connect("localhost","id20969857_root","Rohan@123","id20969857_intern23");
$sql="Select * from users where name like '%$name%'";
$result=mysqli_query($con,$sql);
echo "<table border=1><tr><th>ID</th><th>Name</th><th>Email</th><th>City</th></tr>";
while ($row=mysqli_fetch_array($result))
{
	echo "<tr>";
	echo "<td>".$row[0]."</td>";
	echo "<td>".$row[1]."</td>";
	echo "<td>".$row[2]."</td>";
	echo "<td>".$row[3]."</td>";
	echo "</tr>";	
}
	echo "</table>";
?>
<style>
table{
width:100%;
border-collapse:collapse;
padding:10px;
}
th{
height:70px;
padding:10px;
color:blue;
background-color:#EFEFEF;
}
td{
padding:10px;
}
</style>