<?php
$uname=$_GET["t1"];
$newname=$_GET["t2"];
$con=mysqli_connect("localhost","id20969857_root","Rohan@123","id20969857_intern23");
$sql="Update users set name='$newname' where username='$uname'";
if (mysqli_query($con,$sql))
{
	echo "$uname's Name Updated";
}
else
{
	echo "Unable to update name.. try again";
}

?>
