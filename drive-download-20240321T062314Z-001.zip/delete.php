<?php
$uname=$_GET["t1"];

$con=mysqli_connect("localhost","id20969857_root","Rohan@123","id20969857_intern23");
$sql="Delete from users where username='$uname'";
if (mysqli_query($con,$sql))
{
	echo "$uname's record deleted";
}
else
{
	echo "Unable to delete record.. try again";
}

?>
