<?php
$uname=$_GET["t1"];

$con=mysqli_connect("localhost","root","","phptest");
$sql="Select * from users2 where username='$uname'";
$result=mysqli_query($con,$sql);

if($row=mysqli_fetch_array($result))
{
	echo "<span class='c1'>Username already exist.Try another</span>";
	
}
else
{
echo "<span class='c2'>Username is available</span>";
}

mysqli_close($con);

?>
<style>
.c1{color:red;}
.c2{color:green}
</style>
